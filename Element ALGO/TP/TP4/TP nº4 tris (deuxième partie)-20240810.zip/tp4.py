#!/usr/bin/env python3

from tp3 import *


############################################################
# Exercice 1.1
#
# Tri rapide avec mémoire auxiliaire et en place
#

def triRapideNaif(T, alea=False) :
    # À COMPLÉTER
    return T

def triRapideEnPlace(T, debut=0, fin=None, alea=False) :
    # À COMPLÉTER
    return T

############################################################
# Exercice 1.2
#
# Tri rapide avec mémoire auxiliaire et en place avec pivot
# aléatoire : modifier les deux fonctions précédentes
#

def triRapideRandomise(T) :
    return triRapideNaif(T, alea=True)

def triRapideEnPlaceRandomise(T) :
    return triRapideEnPlace(T, debut=0, fin=len(T), alea=True)


############################################################
# Exercice 2.1
#
# les tableaux de taille < 15 sont triés par insertion, le
# reste avec l'algo de tri rapide usuel (randomisé bien sûr)
#

def triRapideAmeliore(T) :
    # À COMPLÉTER
    return T

############################################################
# Exercice 2.2
#
# Tri rapide (randomisé) seulement pour les tableaux de taille 
# >= 15 et ne fait rien pour les tableaux de taille < 15
#

def triRapidePartiel(T) :
    # À COMPLÉTER
    return T

############################################################
# Exercice 2.3
#
# Trie par insertion le résultat de triRapidePartiel(T).
#

def triSedgewick(T) :
    # À COMPLÉTER
    return T


############################################################
# Exercice 3.1
#
# Fusionne les tranches T[deb:mil] et T[mil:fin] "presque en 
# place", c'est-à-dire en utilisant comme seule mémoire auxiliaire une
# copie de T[deb:mil], puis en réalisant la fusion directement dans
# T[deb:fin]

def fusionAmelioree(T, deb, mil, fin) :
    # À COMPLÉTER
    return T

def triFusionAmeliore(T, deb=0, fin=None) :
    # À COMPLÉTER
    return T


############################################################
# Exercice 3.2
#
# Générateur retournant, à chaque appel, les bornes de la
# monotonie suivante de T (sous-tableau de longueur maximale)

def monotonies(T) :
    deb = fin = 0
    while fin < len(T) :
        #
        # À COMPLÉTER
        #

        # à chaque fois qu'une monotonie maximale est trouvée, on renvoie
        # ses bornes (avec yield, plutôt que return, ainsi l'appel
        # suivant au générateur poursuivra l'exécution à partir de ce
        # point)
        yield deb, fin


############################################################
# Exercice 3.3
#
# Initialise une **file** avec les (bornes des) monotonies de T, 
# puis tant que la file contient au moins 2 éléments :
# - si la monotonie en tête de file correspond à la fin de T, 
#   l'extrait et la replace en fin de file,
# - sinon, extrait et fusionne deux monotonies et replace le 
#   résultat dans la file.

def triFusionNaturel(T) :
    file = [ m for m in monotonies(T) ]
    # À COMPLÉTER
    return T

############################################################
# Exercice 3.4 (tri à la manière de TimSort)
#
# Remplit une pile de monotonies de T en maintenant la condition de pile
# suivante : si m1 est la monotonie en sommet de pile, et m2 juste en
# dessous, alors len(m2) >= 2*len(m1)
# Pour maintenir cette condition, il peut être nécessaire de fusionner
# les deux monotonies en sommet de pile (et éventuellement de
# recommencer).
# Une fois toutes les monotonies empilées, les dépiler deux à deux,
# les fusionner, et réempiler le résultat

def triFaconTimSort(T) :
    monos = monotonies(T)
    premiere = next(monos)
    pile = [ premiere ]
    for m in monos :
        pile.append(m)
        # À COMPLÉTER
    # À COMPLÉTER
    return T


##############################################################
#
# Main
#

if __name__ == '__main__' :
    trisLents = [ triSelection, triBulles ]
    trisInsertion = [ triInsertionEchange, triInsertionRotation, triInsertionRapide ]
    trisRapides = [ triRapideNaif, triRapideEnPlace, triRapideRandomise, triRapideEnPlaceRandomise ]
    trisRapidesHybrides = [ triRapideAmeliore, triSedgewick ]
    trisFusions = [ triFusion, triFusionAmeliore ] 
    trisFusionsHybrides = [ triFusionNaturel, triFaconTimSort ]

    sys.setrecursionlimit(10000)

# Exercice 1

    # print("Exercice 1")
    # algos = trisRapides + [ triFusion ]
    # compareAlgos(algos)
    # algos = [ triInsertionRotation, triInsertionRapide, triFusion, triRapideEnPlaceRandomise]
    # compareAlgosSurTableauxTries (algos)

    ###################################################################
    ##### Commentez ici les résultats obtenus pour les différents #####
    ##### algorithmes sur les différents types de tableaux ############
    ###################################################################
    # commentaires...
    ###################################################################

# Exercice 2

    # print("Exercice 2")
    # algos = trisRapidesHybrides + [ triRapideRandomise, triFusion ]
    # compareAlgos(algos, taille=2000, pas=200)

    ###################################################################
    ##### Commentez ici les résultats obtenus pour les différents #####
    ##### algorithmes sur les différents types de tableaux ############
    ###################################################################
    # commentaires...
    ###################################################################

# Exercice 3

    # print("Exercice 3")
    # algos = trisFusionsHybrides + [ triRapideRandomise, triFusion ]
    # compareAlgos(algos, taille=2000, pas=200)
    # algos = [ triInsertionRotation, triFusionNaturel, triFaconTimSort, triShell ]
    # compareAlgosSurTableauxTries(algos)

    ###################################################################
    ##### Commentez ici les résultats obtenus pour les différents #####
    ##### algorithmes sur les différents types de tableaux ############
    ###################################################################
    # commentaires...
    ###################################################################

